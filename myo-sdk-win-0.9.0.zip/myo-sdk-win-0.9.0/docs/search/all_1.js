var searchData=
[
  ['conjugate',['conjugate',['../classmyo_1_1_quaternion.html#a76dc234322c0cdecd0dc87bad8819345',1,'myo::Quaternion']]],
  ['cross',['cross',['../classmyo_1_1_vector3.html#ad46f10d6d61fb47acf70de678533c618',1,'myo::Vector3']]]
];
