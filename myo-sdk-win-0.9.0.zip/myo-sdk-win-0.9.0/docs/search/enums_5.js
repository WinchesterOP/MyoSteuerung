var searchData=
[
  ['vibrationtype',['VibrationType',['../classmyo_1_1_myo.html#a13be9e9075fb3cf5d47ba491306f3271',1,'myo::Myo']]]
];
